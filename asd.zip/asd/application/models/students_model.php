<?php

class Students_model extends CI_Model {
	
	protected $table = 'students';
	public function __construct() {
		parent::__construct();
	}
	
	public function update($zxc)
	{
		$fields = array(
		'fname' => $zxc['stud_fname'],
		'lname' => $zxc['stud_lname'],
		'username' => $zxc['stud_email'],
		'password' => $zxc['stud_pass'],
		'bday' => $zxc['stud_bday'],
		'address' => $zxc['stud_address'],
		'contact' => $zxc['stud_contact'],
		'pog' => $zxc['stud_pog'],
		);
		$conditions =  array(
		'id' => $zxc['stud_id'],
		);
		$query = $this->db->get_where($this->table, $conditions) ;
		$results = $query->result_array();
		if( ! empty($results))
		{
			
			//process update table
			$this->db->where($conditions);
			$this->db->update($this->table, $fields);
		}
		else
		{
			// process add table
		$this->db->insert($this->table, $fields);
			
		}
		
	}
	
	
		
		
	}