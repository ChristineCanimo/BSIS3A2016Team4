<html>
    <head>
        <title>Insert Data Into Database Using CodeIgniter Form</title>
        <link href='http://fonts.googleapis.com/css?family=Marcellus' rel='stylesheet' type='text/css'/>
        <link  rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style2.css" />
    </head>
    <body>

        <div id="container">
            <form method="POST" action="add">
			<input type="submit" value="ADD STUDENT">
			
            <h1>Insert Data Into Database Using CodeIgniter</h1><hr/> 
            <?php if (isset($message)) { ?>
                <CENTER><h3 style="color:green;">Data inserted successfully</h3></CENTER><br>
            <?php } ?>
                Username <input type ="text" id = "uname" name="username" placeholder="Enter Username"> <br />
            <br />

             Password <input type ="password" id="pass" name="password" placeholder="Enter Password"><br />
           <br />

             Name <input type ="text" id= "name" name="name" placeholder="Enter Full Name"> <br />
           <br />

             Grade and Section <input type ="text" id="gas" name="name" placeholder="Enter Grade&Section"> <br />
            <br />
			
			Teacher <input type ="text" name="name" id= "teach"placeholder="Enter Teacher"> <br />
          <br />

			 Subject <input type ="text" name="name" id="subj" placeholder="Enter Subject"> <br />
           <br />
			
              <input type ="submit" value="ADD STUDENT"> 
            </form><br/>
           <div id="fugo">
			</form>
            </div>
        </div>
    </body>
</html>
