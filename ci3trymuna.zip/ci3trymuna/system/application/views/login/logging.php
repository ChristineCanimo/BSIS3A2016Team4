<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Student's Login</title>
    
    
    
    <link rel='stylesheet prefetch' href='http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/themes/smoothness/jquery-ui.css'>

        <link rel="stylesheet" href="<?php echo base_url()?>css/style.css">

    
    
    
  </head>

  <body>

    <link href='http://fonts.googleapis.com/css?family=Ubuntu:500' rel='stylesheet' type='text/css'>
<br><br><br>
<div class="login">
  <div class="login-header">
    <h1>Student's Login</h1>
  </div>
  <div class="login-form">
  <form method="POST" action="students"><br>
   <div id="body">
		<form method="POST" action=""><br>
		Username <input type ="text" name="username" placeholder="Enter Username"><br /><br>
		Password <input type ="password" name="password" placeholder="Enter Password"><br />
		<br><br>
		<input type="submit"  value="Login"><br><br>
 
    <br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a class="sign-up">No Account? Sign Up!</a>
    <br>
    <h6 class="no-access"></h6></form>
  </div>
</div>

    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js'></script>

        <script src="js/index.js"></script>

    
    
    
  </body>
</html>
