<?php

class table_model extends CI_Model{
	
	public function __construct() {
		parent::__construct();
	}

	 function showstudents($id = null){
			if(!isset($id) && $id == null)
			$result = $this->db->get('students');
		else {
			$this->db->where('StudentNo', $id);
			$result = $this->db->get('students');
		}
		
		return $result->result_array();
    }
	
	 function form_insert($data){
 
       $this->db->insert('students', $data);  
    }    
	
	
}

?>

