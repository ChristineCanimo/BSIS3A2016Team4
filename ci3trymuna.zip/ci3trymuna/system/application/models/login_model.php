<?php
class login_model extends CI_Model {
	public function __constraint() {
	parent:: __constraint();
	
	}

        public function logging()
        {
                $this->load->view('login/logging');
        }
		
		public function logging2()
        {
                $this->load->view('login/logging2');
        }

		public function studentslogin ($Username, $Password){
		$sa = $_POST['username'];
		$pa = $_POST['password'];
		$sql = "SELECT username, password from students";
		$result = $conn->query($sql);

		if ($result->num_rows!=0) 
		{

		while($row = $result->fetch_assoc())
		{
		$a = $row["username"];
		$b = $row["password"];
		if($sa == $a && $pa == $b) {
		
		$this->load->view('login/logging2');
		}
		else{
			$this->load->view('login/welcome');
		}
		
}
}
		}
		

		
		public function students() {

			$this->load->view('login/students');
	}
	
	public function addstud() {
			
			$this->load->view('login/addstud');
		}
	
	function showstudents($id = null){
			if(!isset($id) && $id == null)
			$result = $this->db->get('students');
		else {
			$this->db->where('StudentNo', $id);
			$result = $this->db->get('students');
		}
		
		return $result->result_array();
    }
	
	 function form_insert($data){
 
       $this->db->insert('students', $data);  
    }    
	
}