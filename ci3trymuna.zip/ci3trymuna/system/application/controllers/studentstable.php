<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class studentstable extends CI_Controller{

function __construct(){
parent::__construct();
$this->load->model('table_model');
}


	public function showstudtable() {
       $this->load->model('table_model');
		
		$results['students'] = $this->table_model->showstudents();

		$this->load->view('login/students', $results);
	}
    
	
	
	 public function insert() {
        //Including validation library
        $this->load->library('form_validation');

        $this->form_validation->set_error_delimiters('<div class="error">', '</div>');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('login/add');
        } else {
            //Setting values for tabel columns
            $data = array(
                'Username' => $this->input->post('uname'),
                'Password' => $this->input->post('pass'),
                'Name' => $this->input->post('name'),
                'Grade&Section' => $this->input->post('gas'),
				'Teacher' => $this->input->post('teach'),
				'Subject' => $this->input->post('subj'),
            );
            //Transfering data to Model
            $this->table_model->form_insert($data);
            $data['message'] = 'Data Inserted Successfully';
            //Loading View
            $this->load->view('login/add', $data);
        }
    }
	
	
	
	}
	
	

?>