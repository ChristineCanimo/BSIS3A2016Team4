<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class login extends CI_Controller {
	public function __construct() {
		parent::__construct();
	}
	
	public function welcome()
	{
		$this->load->helper('url');
		$this->load->view('login/welcome');
		
}

	public function logging() {
		
		if($this->input->post()) {
		
		$this->load->helper('url');
		$this->load->model('login_model');
			
			$data=$this->input->post();
			$result = $this->login_model->logging();
}
}
	public function logging2() {
		
		if($this->input->post()) {
		
		$this->load->helper('url');
		$this->load->model('login_model');
			
			$data=$this->input->post();
			$result = $this->login_model->logging2();
}
}
	public function students() {
		
		if($this->input->post()) {
		
		$this->load->model('login_model');
			
			$data=$this->input->post();
			$result = $this->login_model->students();
		
	}
	}
	
	public function addstud() {
		
		if($this->input->post()) {
		
		$this->load->model('login_model');
			
			$data=$this->input->post();
			$result = $this->login_model->addstud();
}
	}
	
	public function showstudtable() {
       $this->load->model('login_model');
		
		$results['students'] = $this->table_model->showstudents();

		$this->load->view('login/students', $results);
	}
    
	
	

}