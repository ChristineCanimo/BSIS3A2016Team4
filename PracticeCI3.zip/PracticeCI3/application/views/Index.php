<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<head>
	
	<title> Add and Update </title>

	</head>
<body>



</body>

<form action="add" method="POST">

	<input type="text" name="stud_id" placeholder="Student ID" />
	<input type="text" name="stud_fname" placeholder="Enter First Name" />
	<input type="text" name="stud_lname" placeholder="Enter Last Name" />
	<input type="text" name="stud_add" placeholder="Enter Address" />
	<input type="password" name="stud_pass" placeholder="Enter Password" />
	<button type="submit" name="add_student" value="save"> ADD STUDENT </button>
	
</form>

</html>
	