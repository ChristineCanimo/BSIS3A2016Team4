<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Add extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
	
		$this->load->model(array('stud_model'));
	}

	
	public function index()
	{
		$id = NULL;
		$stud_fname = NULL;
		$stud_lname = NULL;
		$stud_add = NULL;
		$stud_pass = NULL;
		$add_student = NULL;
		
		extract($_POST);
		
		$student['id'] = $id;
		$student['stud_fname'] = $stud_fname;
		$student['stud_lname'] = $stud_lname;
		$student['stud_add'] = $stud_add;
		$student['stud_pass'] = $stud_pass;
		
		if(isset($submit))
		{
			//insert and update of table
			
			$this->stud_model->update($student);
			
			
		}
		
		$this->load->view('index');
	}
}