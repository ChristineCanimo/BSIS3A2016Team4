<?php if ( ! defined ('BASEPATH')) exit ('No direct script access allowed');

class Stud_model extends CI_Model {
	
	protected $table = 'students';
	function __construct()
	{
		parent::__construct();
	}
	
	
	public function update($student)
	{
		$fields = array(
		 'fname' => $student['stud_fname'],
		 'lname' => $student['stud_lname'],
		 'address' => $student['stud_add'],
		 'password' => $student['stud_pass'],
	
		);
		
		//check if data is existing
		$conditions = array(
		'stud_id' => $students['id'],
		'del_flag' => 0
		
		
		
		);
		$query = $this->db->get_where($this-table, $conditions);
		$results = $query->result_array();
		if( ! empty($results))
		{
			$fields ['updated_date'] = date('Y:a:d M:i:s');
			//process update table
			$this->db->where($conditions);
			$this->db->updated($this->table, $fields);
		}	
		else
		{
			$fields ['created_date'] = date('Y:a:d M:i:s');
			// process insert table
			$this->db->insert($this->table, $fields);
			
		}
		
		
		
	}





}